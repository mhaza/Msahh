import 'package:flutter/material.dart';

/// نمط الخطوط الهندسية الخفيف في خلفية التطبيق (كما في الأصل)
class BackgroundPattern extends StatelessWidget {
  final Widget child;
  const BackgroundPattern({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: CustomPaint(painter: _PatternPainter()),
        ),
        child,
      ],
    );
  }
}

class _PatternPainter extends CustomPainter {
  static const lineColor = Color(0x0A1A2A3A);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = lineColor
      ..strokeWidth = 1.0;

    const step = 110.0;
    // خطوط قطريّة خفيفة متقاطعة تشكل شبكة هندسية
    for (double x = -size.height; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height), paint);
      canvas.drawLine(Offset(x, size.height), Offset(x + size.height, 0), paint);
    }
    // نقاط تقاطع
    final dotPaint = Paint()..color = const Color(0x14BF9742);
    for (double x = 0; x < size.width + step; x += step) {
      for (double y = 0; y < size.height + step; y += step) {
        canvas.drawCircle(Offset(x, y), 2.5, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
