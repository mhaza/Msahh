import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/home_screen.dart';
import 'theme.dart';

void main() {
  runApp(const HamdanApp());
}

class HamdanApp extends StatelessWidget {
  const HamdanApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'همدان',
      debugShowCheckedModeBanner: false,
      theme: HamdanTheme.lightTheme,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        // منع أي نص يتجاوز حجمه من كسر التخطيط
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(
            MediaQuery.of(context).textScaler.scale(1.0).clamp(0.85, 1.3),
          )),
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const HomeScreen(),
    );
  }
}
