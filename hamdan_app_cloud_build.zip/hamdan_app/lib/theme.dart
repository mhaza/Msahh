import 'package:flutter/material.dart';

/// ألوان التطبيق المستخرجة من النسخة الأصلية بدقة
class HamdanColors {
  static const Color gold = Color(0xFFBF9742);        // شريط العنوان
  static const Color goldButton = Color(0xFFBBA166);  // الأزرار
  static const Color goldLight = Color(0xFFCEB268);   // تدرج فاتح
  static const Color goldPale = Color(0xFFECDCBA);    // خلفية الأيقونات داخل البطاقات
  static const Color background = Color(0xFFF9FAFC);    // خلفية الصفحة
  static const Color cardShadow = Color(0x14000000);
  static const Color textDark = Color(0xFF2B2B2B);
  static const Color textGrey = Color(0xFF747474);
}

class HamdanTheme {
  static ThemeData get lightTheme {
    final base = ThemeData.light(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: HamdanColors.background,
      colorScheme: base.colorScheme.copyWith(
        primary: HamdanColors.gold,
        secondary: HamdanColors.goldButton,
        surface: Colors.white,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: HamdanColors.gold,
        foregroundColor: Colors.white,
        elevation: 4,
        centerTitle: true,
        titleTextStyle: TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
        iconTheme: IconThemeData(color: Colors.white, size: 28),
      ),
      cardTheme: CardTheme(
        color: Colors.white,
        elevation: 6,
        shadowColor: HamdanColors.cardShadow,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        margin: EdgeInsets.zero,
      ),
      dividerTheme: const DividerThemeData(color: Color(0xFFE8E8E8), thickness: 1),
    );
  }
}
