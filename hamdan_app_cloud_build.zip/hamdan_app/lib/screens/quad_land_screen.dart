import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme.dart';
import '../widgets/background_pattern.dart';

class QuadLandScreen extends StatefulWidget {
  const QuadLandScreen({super.key});

  @override
  State<QuadLandScreen> createState() => _QuadLandScreenState();
}

class _QuadLandScreenState extends State<QuadLandScreen> {
  final _projectName = TextEditingController(text: 'المشروع: جديد 1');
  final _ab = TextEditingController();
  final _bc = TextEditingController();
  final _cd = TextEditingController();
  final _ad = TextEditingController();
  final _ac = TextEditingController();

  String _result = '0.00000';
  String _unit = 'متر مربع';

  @override
  void dispose() {
    for (final c in [_projectName, _ab, _bc, _cd, _ad, _ac]) {
      c.dispose();
    }
    super.dispose();
  }

  /// مساحة الرباعي الدائري (قانون براهماغوبتا) — نفس منطق التطبيق الأصلي
  void _calculate() {
    final sides = [_ab, _bc, _cd, _ad].map(_parse).toList();
    final diagonal = _parse(_ac);
    if (sides.any((s) => s == null || s! <= 0) || diagonal == null || diagonal <= 0) {
      _showError('يرجى إدخال جميع الأطوال بأرقام صحيحة موجبة');
      return;
    }
    final a = sides[0]!, b = sides[1]!, c = sides[2]!, d = sides[3]!;
    final s = (a + b + c + d) / 2;
    final inner = (s - a) * (s - b) * (s - c) * (s - d);
    if (inner <= 0) {
      _showError('الأطوال المدخلة لا تشكل رباعياً صحيحاً');
      return;
    }
    setState(() {
      _result = (math.sqrt(inner)).toStringAsFixed(5);
    });
  }

  double? _parse(TextEditingController c) {
    final t = c.text.trim().replaceAll(',', '.');
    return t.isEmpty ? null : double.tryParse(t);
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: Colors.redAccent),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HamdanColors.background,
      appBar: AppBar(
        title: const FittedBox(
          fit: BoxFit.scaleDown,
          child: Text('حساب مساحة أرض رباعية الأضلاع'),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 14),
            child: Icon(Icons.folder, size: 28),
          ),
        ],
      ),
      body: BackgroundPattern(
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final w = constraints.maxWidth;
              final narrow = w < 420;
              final fieldHeight = narrow ? 52.0 : 58.0;
              final smallGap = narrow ? 8.0 : 14.0;

              return SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                  horizontal: w * 0.04,
                  vertical: constraints.maxHeight * 0.02,
                ),
                child: Column(
                  children: [
                    // اسم المشروع
                    Container(
                      height: fieldHeight,
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFFE3E3E3)),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _projectName,
                              textAlign: TextAlign.right,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                isDense: true,
                              ),
                              style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: HamdanColors.textGrey),
                            ),
                          ),
                          const Icon(Icons.folder_open,
                              color: HamdanColors.textGrey),
                        ],
                      ),
                    ),
                    SizedBox(height: smallGap + 6),

                    // رسم توضيحي للرباعي
                    AspectRatio(
                      aspectRatio: 2.1,
                      child: CustomPaint(
                        painter: _QuadPainter(),
                        size: Size.infinite,
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text(
                        'أدخل أطوال الاضلاع الخارجية واحد القطرين\n*أدخل الأطوال بالمتر',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 13, color: HamdanColors.textGrey, height: 1.6),
                      ),
                    ),

                    // صف الأضلاع الثلاثة الأولى — مرن مهما ضاقت الشاشة
                    Row(
                      children: [
                        Expanded(child: _SideField(controller: _ab, label: 'أ ب', height: fieldHeight)),
                        SizedBox(width: smallGap),
                        Expanded(child: _SideField(controller: _bc, label: 'ب ج', height: fieldHeight)),
                        SizedBox(width: smallGap),
                        Expanded(child: _SideField(controller: _cd, label: 'ج د', height: fieldHeight)),
                      ],
                    ),
                    SizedBox(height: smallGap + 6),
                    // الصف الثاني: ضلع + قطر
                    Row(
                      children: [
                        const Icon(Icons.layers, color: HamdanColors.gold, size: 30),
                        const SizedBox(width: 4),
                        Text('أ ج',
                            style: TextStyle(
                                fontSize: narrow ? 15 : 17,
                                fontWeight: FontWeight.w700)),
                        SizedBox(width: smallGap),
                        Expanded(child: _SideField(controller: _ad, label: 'د أ', height: fieldHeight)),
                        SizedBox(width: smallGap),
                        Expanded(child: _SideField(controller: _ac, label: 'أ ج', height: fieldHeight)),
                      ],
                    ),
                    SizedBox(height: smallGap + 10),

                    // الوحدة + النتيجة
                    Row(
                      children: [
                        Expanded(
                          flex: 4,
                          child: Container(
                            height: fieldHeight + 6,
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: const Color(0xFFE3E3E3)),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.settings,
                                    color: HamdanColors.gold, size: 26),
                                const VerticalDivider(
                                    width: 18,
                                    color: Color(0xFFE8E8E8),
                                    indent: 10,
                                    endIndent: 10),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: DropdownButtonHideUnderline(
                                    child: DropdownButton<String>(
                                      value: _unit,
                                      isExpanded: true,
                                      icon: const Icon(Icons.arrow_drop_down,
                                          color: HamdanColors.goldButton),
                                      style: const TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.black87),
                                      items: const [
                                        DropdownMenuItem(
                                            value: 'متر مربع',
                                            child: Text('متر مربع')),
                                        DropdownMenuItem(
                                            value: 'فدان',
                                            child: Text('فدان')),
                                        DropdownMenuItem(
                                            value: 'قيراط',
                                            child: Text('قيراط')),
                                      ],
                                      onChanged: (v) => setState(() => _unit = v!),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(width: smallGap),
                        Expanded(
                          flex: 5,
                          child: Container(
                            height: fieldHeight + 6,
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: const Color(0xFFE3E3E3)),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.keyboard,
                                    color: HamdanColors.textGrey, size: 26),
                                const SizedBox(width: 8),
                                const Text('المساحة:',
                                    style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700)),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: FittedBox(
                                    alignment: Alignment.centerRight,
                                    fit: BoxFit.scaleDown,
                                    child: Text(
                                      _result,
                                      style: const TextStyle(
                                          fontSize: 17,
                                          fontWeight: FontWeight.w800,
                                          color: Color(0xFF4A6572)),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: constraints.maxHeight * 0.035),

                    // زر الحساب
                    Center(
                      child: Material(
                        color: HamdanColors.goldButton,
                        borderRadius: BorderRadius.circular(40),
                        elevation: 6,
                        child: InkWell(
                          onTap: _calculate,
                          borderRadius: BorderRadius.circular(40),
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                              horizontal: w * 0.17,
                              vertical: narrow ? 16 : 20,
                            ),
                            child: const Text(
                              '=  احسب الآن',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 21,
                                  fontWeight: FontWeight.w800),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 90), // مساحة لزر عائم
                  ],
                ),
              );
            },
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        backgroundColor: HamdanColors.gold,
        elevation: 6,
        child: const Icon(Icons.assignment, color: Colors.white, size: 28),
      ),
    );
  }
}

class _SideField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final double height;

  const _SideField({
    required this.controller,
    required this.label,
    required this.height,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE3E3E3)),
      ),
      child: TextField(
        controller: controller,
        textAlign: TextAlign.center,
        keyboardType:
            const TextInputType.numberWithOptions(decimal: true, signed: true),
        inputFormatters: [
          FilteringTextInputFormatter.allow(RegExp(r'[\d.,-]')),
        ],
        style: const TextStyle(
            fontSize: 17, fontWeight: FontWeight.w800, color: Colors.black87),
        decoration: InputDecoration(
          hintText: label,
          hintStyle:
              const TextStyle(color: HamdanColors.goldButton, fontSize: 17),
          border: InputBorder.none,
          isDense: true,
          contentPadding: EdgeInsets.zero,
        ),
      ),
    );
  }
}

/// رسم توضيحي للرباعي أ ب ج د مع القطرين
class _QuadPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    // إحداثيات مرنة نسبةً لحجم المساحة (تمنع أي تداخل مهما تغيّر الحجم)
    final a = Offset(w * 0.88, h * 0.18);
    final b = Offset(w * 0.92, h * 0.86);
    final c = Offset(w * 0.08, h * 0.90);
    final d = Offset(w * 0.06, h * 0.10);

    final fillPaint = Paint()
      ..color = const Color(0xFFEAF0FA)
      ..style = PaintingStyle.fill;
    final strokePaint = Paint()
      ..color = Colors.black87
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6;
    final diagPaint = Paint()
      ..color = const Color(0xFFB9C4D4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    final path = Path()
      ..moveTo(a.dx, a.dy)
      ..lineTo(b.dx, b.dy)
      ..lineTo(c.dx, c.dy)
      ..lineTo(d.dx, d.dy)
      ..close();
    canvas.drawPath(path, fillPaint);
    canvas.drawPath(path, strokePaint);

    canvas.drawLine(a, c, diagPaint);
    canvas.drawLine(b, d, diagPaint);

    _label(canvas, 'أ', a.translate(10, -14));
    _label(canvas, 'ب', b.translate(10, 4));
    _label(canvas, 'ج', c.translate(-24, 4));
    _label(canvas, 'د', d.translate(-24, -14));
  }

  void _label(Canvas canvas, String t, Offset o) {
    final tp = TextPainter(
      text: TextSpan(
          text: t,
          style: const TextStyle(
              color: Colors.black, fontSize: 20, fontWeight: FontWeight.w800)),
      textDirection: TextDirection.rtl,
    )..layout();
    tp.paint(canvas, o);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
