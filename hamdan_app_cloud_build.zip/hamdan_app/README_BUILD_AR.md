# مشروع تطبيق همدان — جاهز للبناء السحابي

تم إصلاح اعتماد `flutter_localizations` الناقص في `pubspec.yaml`، والإبقاء على إعداد بناء APK عبر GitHub Actions.

## استخراج APK دون تثبيت Flutter أو Android Studio على هاتفك

1. سجّل الدخول إلى GitHub وأنشئ مستودعًا جديدًا فارغًا باسم `hamdan-app`.
2. ارفع **محتويات هذا المجلد** إلى المستودع (وليس ملف ZIP نفسه).
3. افتح تبويب **Actions** في المستودع.
4. اختر سير العمل **Build Hamdan APK** ثم اضغط **Run workflow**.
5. بعد انتهاء البناء بنجاح، افتح تنفيذ العملية وانزل إلى **Artifacts**.
6. نزّل `hamdan-app-release` وفك ضغطه لتحصل على `app-release.apk`.

## البناء محليًا

يتطلب Flutter SDK وAndroid SDK، ثم نفّذ:

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

مسار الناتج: `build/app/outputs/flutter-apk/app-release.apk`

> ملاحظة: لم يُنتج APK داخل هذه البيئة؛ لا تتوفر فيها Flutter SDK أو Android SDK أو Gradle. إعداد GitHub Actions يتيح تنفيذ البناء على خادم GitHub بعد رفع المشروع.
